import express from 'express';
import AuthController from '../controllers/AuthController.js';

const router = express.Router();

console.log("✅ authRoute.js đã được load!");

router.post('/register', (req, res, next) => {
    console.log("📢 API nhận request tại /register");
    console.log("📢 Body từ frontend:", req.body);
    next();
  }, AuthController.register);

router.post('/login', AuthController.login);

export default router;
