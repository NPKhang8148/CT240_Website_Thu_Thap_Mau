import React from 'react';
import Box from '@mui/material/Box';
function Overview() {
  const styles = {
    main: {
      width: '100%',
      background:
        'linear-gradient(to top, rgba(0, 0, 0, 0.5) 50%, rgba(0, 0, 0, 0.5) 50%), url(src/assets/Background_4.jpg)',
      backgroundPosition: 'center',
      backgroundSize: 'cover',
      height: '100vh',
      paddingTop: '40px',
    },
    navbar: {
      width: '100%',
      height: '75px',
      margin: 'auto',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    content: {
      width: '100%',
      height: 'auto',
      margin: 'auto',
      color: '#fff',
      position: 'relative',
    },
    heading: {
      fontFamily: 'Arial, Helvetica, sans-serif',
      fontSize: { xs: '1rem', md: '3.5rem' },
      paddingLeft: '20px',
      marginTop: '0px',
      letterSpacing: '2px',
    },
    Agriculture: {
      color: '#83c13b',
    },
    paragraph: {
      paddingLeft: '20px',
      paddingBottom: '25px',
      fontFamily: 'Arial',
      letterSpacing: '1.2px',
      lineHeight: '30px',
    },
    menuItem: {
      listStyle: 'none',
      marginLeft: '62px',
      marginTop: '27px',
      fontSize: '15px',
    },
    link: {
      textDecoration: 'none',
      color: '#fff',
      fontFamily: 'Arial',
      fontWeight: 'bold',
      transition: '0.4s ease-in-out',
    },
  };

  return (
    <Box sx={styles.main}>
      <Box sx={styles.content}>
        <h1 style={styles.heading}>
          SAMPLE COLLECTING
          <br />
        </h1>
        <p style={styles.paragraph}>
        The Sample Collection System is developed to facilitate sample collection, sample management, and member administration. The system’s primary users consist of project managers and team members across different organizational settings. It primarily operates in an online environment, accessible via web browsers and compatible with multiple devices, including computers and mobile devices.
        </p>
      </Box>
    </Box>
  );
}

export default Overview;
